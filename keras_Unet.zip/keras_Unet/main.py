import try_mnist

label = try_mnist.load_mnist()
print(label)